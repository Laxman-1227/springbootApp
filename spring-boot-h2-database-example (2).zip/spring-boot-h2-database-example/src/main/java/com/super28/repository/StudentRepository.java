package com.super28.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.super28.model.Student;

public interface StudentRepository extends CrudRepository<Student, Integer> {
	
	@Query(value = "select * from Student where username = :username ", nativeQuery = true)
	public List<Student> getUserByName(String username);
	
	//select * from user where name = 'Laxman';
	
}


// spring data jpa jar(dependency)

//spring jdbcTemplate jar(dependency)

// hibernate jar(dependency)


