package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class StudentController {
	
	@Autowired
	JdbcTemplate firstJdbcTemplate;
	
	@Autowired
	JdbcTemplate secondJdbcTemplate;
	
	@PostMapping("/student")
	private String saveStudent() {
		firstJdbcTemplate.execute("insert into Student values(104, 29, 'studentName', 'abc@student.com') ");
		return "Record inserted successfully";
	}
	
	
	@PostMapping("/employee")
	private String saveEmployee() {
		secondJdbcTemplate.execute("insert into employee values(104, 29,'abc@employee.com', 'employeName' ) ");
		return "Record inserted successfully";
	}

}
