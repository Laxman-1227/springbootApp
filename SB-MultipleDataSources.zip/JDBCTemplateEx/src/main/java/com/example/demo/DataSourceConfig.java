package com.example.demo;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class DataSourceConfig {
	@Value("${spring.firstdatasource.url}")
	String url;
	@Value("${spring.firstdatasource.username}")
	String username;
	@Value("${spring.firstdatasource.password}")
	String password;
	@Value("${spring.firstdatasource.driverClassName}")
	String driverClass;
	
	
	
	@Value("${spring.seconddatasource.url}")
	String urlTest;
	@Value("${spring.seconddatasource.username}")
	String usernameTest;
	@Value("${spring.seconddatasource.password}")
	String passwordTest;
	@Value("${spring.seconddatasource.driverClassName}")
	String driverClassTest;
	
	
	@Bean
	@Primary
	//@ConfigurationProperties(prefix="spring.firstdatasource")
	public DataSource firstDataSource() {
		
		 DriverManagerDataSource dataSource = new DriverManagerDataSource();
		    dataSource.setDriverClassName(driverClass);
		    dataSource.setUrl(url);
		    dataSource.setUsername(username);
		    dataSource.setPassword(password);
		    
		return dataSource;
	}
	
	@Bean
	//@ConfigurationProperties(prefix="spring.seconddatasource")
	public DataSource secondDataSource() {

		 DriverManagerDataSource dataSource = new DriverManagerDataSource();
		    dataSource.setDriverClassName(driverClassTest);
		    dataSource.setUrl(urlTest);
		    dataSource.setUsername(usernameTest);
		    dataSource.setPassword(passwordTest);
		return dataSource;
	}
	
	
	@Bean()
	public JdbcTemplate firstJdbcTemplate(@Qualifier("firstDataSource") DataSource ds) {
		return new JdbcTemplate(ds);
	}
	
	
	@Bean
	public JdbcTemplate secondJdbcTemplate(@Qualifier("secondDataSource") DataSource ds) {
		return new JdbcTemplate(ds);
	}

}
