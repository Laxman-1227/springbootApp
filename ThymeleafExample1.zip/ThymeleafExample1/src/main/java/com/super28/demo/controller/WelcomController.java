package com.super28.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class WelcomController {
	private static List<User> userList = new ArrayList<>();
	
	@GetMapping("/viewUsers")
	public ModelAndView viewHomePage(Model model) {
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		
		User usr = new User();
		usr.setEmail("Laxman@Gmail.com");
		usr.setName("Laxman");
		
		User usr1 = new User();
		usr1.setEmail("Teja@Gmail.com");
		usr1.setName("Teja");
		
		User usr2 = new User();
		usr2.setEmail("Manju@Gmail.com");
		usr2.setName("Manju");
		userList.add(usr);
		userList.add(usr1);
		userList.add(usr2);
		modelAndView.addObject("userList", userList);
		return modelAndView;
	}
	
	@GetMapping("/hello")
	public String getMessage() {
		return "Hello World!!";
	}
	
	
	@RequestMapping(value = "/saveEmployee", method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute User user) {
		
		//database
		userList.add(user);
		
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		modelAndView.addObject("userList", userList);
		
		
		return modelAndView;
		
	}
	
	@GetMapping("/showNewEmployeeForm")
	public ModelAndView showNewEmployeeForm(Model model) {
		// create model attribute to bind form data
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("new_employee");
		User user = new User();
		model.addAttribute("employee", user);
		return modelAndView;
	}
		

}
