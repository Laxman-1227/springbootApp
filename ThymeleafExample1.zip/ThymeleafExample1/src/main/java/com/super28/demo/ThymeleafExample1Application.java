package com.super28.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafExample1Application {

	public static void main(String[] args) {
		SpringApplication.run(ThymeleafExample1Application.class, args);
	}

}
