package com.example.firstmsclient.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import reactor.core.publisher.Mono;

@RestController
public class TestController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserClientResource.class);
	
	@Autowired
	RestTemplate restTemplateForClient1;
	
	
	@Autowired
    private WebClient webClient;
	
	@GetMapping("/getResponseFromClient1")
	 @HystrixCommand(fallbackMethod = "getClientHelloFromFallback", commandProperties = {
		      @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "10000")
	   })
	public String getResponseFromClient1() {
		
		return restTemplateForClient1.getForObject("http://ERUKACLIENT1/getMessage", String.class);
	}

	
	private  String getClientHelloFromFallback() {
        LOGGER.info("Falling Back");
        return "Coming from the fallback";
    }
	
	
	
	
	
	@GetMapping("/getResponseFromClient1ByWebclient")
    public Mono<String> getClientHelloWeb() {
        LOGGER.info("WebClient: about to call firstms");
        Mono<String> response = webClient.get().uri("/getMessage")
                .retrieve().bodyToMono(String.class);
        LOGGER.info("WebClient: call completed");
        return response;
    }
}
